# Control de Gastos

> Parcial final — Programación con C# y .NET

## 1. Información general

- **Nombre del proyecto:** Control de Gastos
- **Estudiante:** [TU NOMBRE COMPLETO]
- **Descripción:** Aplicación de escritorio que permite registrar y consultar los ingresos y gastos personales, y ver el balance total.
- **Problema que resuelve:** Muchas personas no llevan un registro de su dinero y no saben cuánto ingresan ni cuánto gastan. La aplicación centraliza esa información en un solo lugar y la conserva aunque se cierre el programa.
- **Objetivo principal:** Aplicar Programación Orientada a Objetos, Avalonia UI y ADO.NET con SQLite en una aplicación sencilla pero completa.

## 2. Funcionalidades

- **Registrar** un movimiento (descripción, monto y tipo: Ingreso o Gasto). La fecha se guarda automáticamente.
- **Consultar** todos los movimientos en una tabla (los más recientes primero).
- **Actualizar** un movimiento: se selecciona una fila, se editan los datos en el formulario y se presiona *Actualizar seleccionado*.
- **Eliminar** el movimiento seleccionado.
- **Ver el balance** (ingresos − gastos) en la parte inferior de la ventana.
- **Validaciones:** descripción obligatoria (máx. 100 caracteres), monto numérico mayor que cero y tipo válido. Los errores se muestran en un mensaje en rojo sin cerrar el programa.
- **Mensajes de confirmación** en verde después de cada operación exitosa.

## 3. Tecnologías utilizadas

| Tecnología | Detalle |
|---|---|
| Lenguaje | C# |
| Plataforma | .NET 8 (`net8.0`; funciona también con SDK 9 y 10) |
| Interfaz gráfica | Avalonia UI 11.3 (archivos `.axaml`) |
| Acceso a datos | ADO.NET con `Microsoft.Data.Sqlite` 8.0 |
| Base de datos | SQLite |
| Paquetes adicionales | `Avalonia.Desktop`, `Avalonia.Themes.Fluent`, `Avalonia.Controls.DataGrid` |

## 4. Estructura del proyecto

```
ControlGastos/
├── ControlGastos.csproj        # Proyecto .NET y paquetes NuGet
├── Program.cs                  # Punto de entrada
├── App.axaml / App.axaml.cs    # Configuración de Avalonia y tema
├── MainWindow.axaml            # Interfaz gráfica (XAML)
├── MainWindow.axaml.cs         # Eventos de la interfaz
├── Models/
│   └── Movimiento.cs           # Clase que representa un ingreso o gasto
├── Data/
│   └── MovimientoDAO.cs        # Acceso a datos: ADO.NET + SQLite (CRUD)
├── Services/
│   └── MovimientoServicio.cs   # Lógica y validaciones
├── database/
│   └── schema.sql              # Esquema de la base de datos (documentación)
├── evidencias/                 # Capturas de las pruebas
└── README.md
```

### Clases principales y responsabilidades

| Clase | Responsabilidad |
|---|---|
| `Movimiento` | Modelo de datos. Representa un ingreso o gasto con sus propiedades. |
| `MovimientoDAO` | Único lugar donde se ejecuta SQL. Crea la tabla y realiza el CRUD. |
| `MovimientoServicio` | Convierte y valida lo que escribe el usuario, calcula el balance y usa el DAO. |
| `MainWindow` | Interfaz: captura los eventos de los botones y muestra los datos. No contiene SQL. |

**Relación entre clases:** `MainWindow` → `MovimientoServicio` → `MovimientoDAO` → SQLite. El objeto `Movimiento` viaja entre las capas.

### Dónde se aplica la POO

- **Clases y objetos:** `Movimiento`, `MovimientoDAO`, `MovimientoServicio` y `MainWindow`.
- **Atributos y propiedades:** `Movimiento` tiene `Id`, `Descripcion`, `Monto`, `Tipo` y `Fecha`.
- **Constructores:** `Movimiento(id, descripcion, monto, tipo, fecha)`; `MovimientoDAO(ruta)`; `MovimientoServicio(dao)`.
- **Métodos:** `Insertar`, `ObtenerTodos`, `Actualizar`, `Eliminar`, `Agregar`, `CalcularBalance`, etc.
- **Encapsulamiento:** en `Movimiento` los campos son privados y las propiedades `Descripcion`, `Monto` y `Tipo` validan el valor antes de guardarlo; `Id` y `Fecha` solo se asignan en el constructor (`private set`).
- **Separación de responsabilidades:** interfaz (`MainWindow`), lógica (`MovimientoServicio`) y datos (`MovimientoDAO`) están en clases distintas.

## 5. Instalación de dependencias

1. Instalar el **SDK de .NET 8 o superior** desde <https://dotnet.microsoft.com/download>. Verificar con:
   ```
   dotnet --version
   ```
2. Instalar **Git** (<https://git-scm.com>).
3. Clonar el repositorio:
   ```
   git clone [URL-DE-TU-REPOSITORIO]
   cd [NOMBRE-DE-LA-CARPETA-DEL-REPOSITORIO]
   ```
4. Restaurar las dependencias (descarga Avalonia y Microsoft.Data.Sqlite):
   ```
   dotnet restore
   ```

No se necesita instalar SQLite aparte: el paquete `Microsoft.Data.Sqlite` ya lo incluye. Se requiere conexión a internet la primera vez para descargar los paquetes NuGet.

## 6. Ejecución del programa

Desde la carpeta que contiene el archivo `ControlGastos.csproj` (la raíz del repositorio):

```
dotnet restore
dotnet run
```

Se abrirá la ventana de la aplicación.

## 7. Base de datos

- **Qué almacena:** los ingresos y gastos registrados por el usuario.
- **Tabla `movimientos`:**

| Campo | Tipo | Descripción |
|---|---|---|
| `id` | INTEGER (PK, autoincremental) | Identificador único |
| `descripcion` | TEXT | Detalle del movimiento |
| `monto` | REAL | Valor del movimiento |
| `tipo` | TEXT | `Ingreso` o `Gasto` |
| `fecha` | TEXT | Fecha de registro (`yyyy-MM-dd`) |

- **Conexión:** `MovimientoDAO` crea un `SqliteConnection` con la cadena `Data Source=<ruta>\gastos.db`. Cada operación abre la conexión dentro de un `using`, de modo que se cierra y libera automáticamente.
- **Consultas seguras:** todas las sentencias SQL usan parámetros (`$descripcion`, `$monto`, `$id`, ...) para los datos del usuario.
- **Dónde está el CRUD:** en `Data/MovimientoDAO.cs`: `Insertar` (Create), `ObtenerTodos` (Read), `Actualizar` (Update) y `Eliminar` (Delete).
- **Inicialización:** la base de datos se **genera automáticamente** al ejecutar el programa por primera vez (`InicializarBaseDeDatos` hace `CREATE TABLE IF NOT EXISTS`). No hay que ejecutar ningún procedimiento previo. El archivo `gastos.db` se crea junto al ejecutable (carpeta `bin/`). El esquema también está en `database/schema.sql`.

## 8. Evidencias de funcionamiento

**Prueba 1 — Registro.** Se agrega un movimiento con descripción, monto y tipo, y se presiona *Guardar*. Resultado: [DESCRIBE LO QUE VISTE, por ejemplo: aparece el mensaje verde y el registro en la tabla].

![Registro](evidencias/01-registro.png)

**Prueba 2 — Consulta.** Se abre la aplicación con registros guardados. Resultado: [DESCRIBE LO QUE VISTE].

![Consulta](evidencias/02-consulta.png)

**Prueba 3 — Actualización.** Se selecciona una fila, se cambian los datos y se presiona *Actualizar seleccionado*. Resultado: [DESCRIBE LO QUE VISTE].

![Actualización](evidencias/03-actualizacion.png)

**Prueba 4 — Eliminación.** Se selecciona una fila y se presiona *Eliminar seleccionado*. Resultado: [DESCRIBE LO QUE VISTE].

![Eliminación](evidencias/04-eliminacion.png)

**Prueba 5 — Validación.** Se intenta guardar con la descripción vacía o con un monto no numérico. Resultado: [DESCRIBE LO QUE VISTE, por ejemplo: se muestra un mensaje en rojo y el programa no se cierra].

![Validación](evidencias/05-validacion.png)

**Prueba 6 — Persistencia.** Se cierra la aplicación y se vuelve a abrir con `dotnet run`. Resultado: [DESCRIBE LO QUE VISTE, por ejemplo: los registros siguen en la tabla].

![Persistencia](evidencias/06-persistencia.png)

## 9. Problemas encontrados y soluciones

**Problema:** [ESCRIBE UN PROBLEMA REAL QUE TE HAYA PASADO. Ejemplo de redacción, úsalo solo si de verdad te ocurrió o lo entendiste al revisar el código:] el monto escrito por el usuario no se convertía a número cuando usaba un formato distinto al de su configuración regional (en Colombia el separador decimal es la coma, no el punto).

**Solución:** se usó `decimal.TryParse` con `CultureInfo.CurrentCulture` y `NumberStyles.AllowDecimalPoint` en `MovimientoServicio`. Si el texto no es un número válido, no se lanza una excepción: se devuelve un mensaje de error comprensible que la interfaz muestra en rojo.
