-- Esquema de la base de datos (SQLite).
-- No hace falta ejecutarlo a mano: la aplicación lo ejecuta sola al iniciar
-- (ver MovimientoDAO.InicializarBaseDeDatos). Se incluye como documentación.

CREATE TABLE IF NOT EXISTS movimientos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    descripcion TEXT    NOT NULL,
    monto       REAL    NOT NULL,
    tipo        TEXT    NOT NULL,   -- 'Ingreso' o 'Gasto'
    fecha       TEXT    NOT NULL    -- formato yyyy-MM-dd
);
