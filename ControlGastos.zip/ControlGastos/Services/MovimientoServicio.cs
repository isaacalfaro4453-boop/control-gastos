using System.Globalization;
using ControlGastos.Data;
using ControlGastos.Models;

namespace ControlGastos.Services;

/// <summary>
/// Lógica del programa: convierte y valida lo que escribe el usuario
/// y se apoya en el DAO para guardar. No conoce la interfaz gráfica.
/// Los métodos Agregar y Actualizar devuelven null si todo salió bien,
/// o un texto con el error para mostrarlo al usuario.
/// </summary>
public class MovimientoServicio
{
    public static readonly string[] Tipos = { "Gasto", "Ingreso" };

    private readonly MovimientoDAO _dao;

    public MovimientoServicio(MovimientoDAO dao)
    {
        _dao = dao;
    }

    public List<Movimiento> Listar() => _dao.ObtenerTodos();

    public string? Agregar(string? descripcion, string? montoTexto, string? tipo)
    {
        if (!TryLeerMonto(montoTexto, out decimal monto, out string? error))
            return error;

        try
        {
            var fecha = DateTime.Now.ToString("yyyy-MM-dd");
            var movimiento = new Movimiento(0, descripcion ?? "", monto, tipo ?? "", fecha);
            _dao.Insertar(movimiento);
            return null;
        }
        catch (ArgumentException ex)
        {
            return ex.Message;
        }
    }

    public string? Actualizar(int id, string? descripcion, string? montoTexto, string? tipo, string fecha)
    {
        if (!TryLeerMonto(montoTexto, out decimal monto, out string? error))
            return error;

        try
        {
            var movimiento = new Movimiento(id, descripcion ?? "", monto, tipo ?? "", fecha);
            _dao.Actualizar(movimiento);
            return null;
        }
        catch (ArgumentException ex)
        {
            return ex.Message;
        }
    }

    public void Eliminar(int id) => _dao.Eliminar(id);

    // Ingresos suman, gastos restan.
    public decimal CalcularBalance(IEnumerable<Movimiento> movimientos) =>
        movimientos.Sum(m => m.Tipo == "Ingreso" ? m.Monto : -m.Monto);

    private static bool TryLeerMonto(string? texto, out decimal monto, out string? error)
    {
        error = null;
        // Solo se permite el separador decimal de la configuración regional (sin separador de miles).
        if (!decimal.TryParse(texto?.Trim(), NumberStyles.AllowDecimalPoint,
                              CultureInfo.CurrentCulture, out monto))
        {
            error = "El monto debe ser un número válido, sin separador de miles (ejemplo: 25000).";
            return false;
        }
        return true;
    }
}
