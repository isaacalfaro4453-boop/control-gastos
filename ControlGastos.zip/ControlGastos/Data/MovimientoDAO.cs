using ControlGastos.Models;
using Microsoft.Data.Sqlite;

namespace ControlGastos.Data;

/// <summary>
/// Acceso a datos (ADO.NET + SQLite). Es la única clase que ejecuta SQL.
/// Implementa el CRUD: Insertar (Create), ObtenerTodos (Read),
/// Actualizar (Update) y Eliminar (Delete).
/// </summary>
public class MovimientoDAO
{
    private readonly string _cadenaConexion;

    public MovimientoDAO(string rutaBaseDatos)
    {
        _cadenaConexion = $"Data Source={rutaBaseDatos}";
        InicializarBaseDeDatos();
    }

    // Crea la tabla si todavía no existe (la base de datos se genera sola al ejecutar).
    private void InicializarBaseDeDatos()
    {
        using var conexion = new SqliteConnection(_cadenaConexion);
        conexion.Open();

        using var comando = conexion.CreateCommand();
        comando.CommandText = @"
            CREATE TABLE IF NOT EXISTS movimientos (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                descripcion TEXT    NOT NULL,
                monto       REAL    NOT NULL,
                tipo        TEXT    NOT NULL,
                fecha       TEXT    NOT NULL
            );";
        comando.ExecuteNonQuery();
    }

    // CREATE
    public void Insertar(Movimiento m)
    {
        using var conexion = new SqliteConnection(_cadenaConexion);
        conexion.Open();

        using var comando = conexion.CreateCommand();
        comando.CommandText = @"
            INSERT INTO movimientos (descripcion, monto, tipo, fecha)
            VALUES ($descripcion, $monto, $tipo, $fecha);";
        comando.Parameters.AddWithValue("$descripcion", m.Descripcion);
        comando.Parameters.AddWithValue("$monto", (double)m.Monto);
        comando.Parameters.AddWithValue("$tipo", m.Tipo);
        comando.Parameters.AddWithValue("$fecha", m.Fecha);
        comando.ExecuteNonQuery();
    }

    // READ
    public List<Movimiento> ObtenerTodos()
    {
        var lista = new List<Movimiento>();

        using var conexion = new SqliteConnection(_cadenaConexion);
        conexion.Open();

        using var comando = conexion.CreateCommand();
        comando.CommandText =
            "SELECT id, descripcion, monto, tipo, fecha FROM movimientos ORDER BY id DESC;";

        using var lector = comando.ExecuteReader();
        while (lector.Read())
        {
            lista.Add(new Movimiento(
                lector.GetInt32(0),
                lector.GetString(1),
                (decimal)lector.GetDouble(2),
                lector.GetString(3),
                lector.GetString(4)));
        }

        return lista;
    }

    // UPDATE
    public void Actualizar(Movimiento m)
    {
        using var conexion = new SqliteConnection(_cadenaConexion);
        conexion.Open();

        using var comando = conexion.CreateCommand();
        comando.CommandText = @"
            UPDATE movimientos
            SET descripcion = $descripcion, monto = $monto, tipo = $tipo
            WHERE id = $id;";
        comando.Parameters.AddWithValue("$descripcion", m.Descripcion);
        comando.Parameters.AddWithValue("$monto", (double)m.Monto);
        comando.Parameters.AddWithValue("$tipo", m.Tipo);
        comando.Parameters.AddWithValue("$id", m.Id);
        comando.ExecuteNonQuery();
    }

    // DELETE
    public void Eliminar(int id)
    {
        using var conexion = new SqliteConnection(_cadenaConexion);
        conexion.Open();

        using var comando = conexion.CreateCommand();
        comando.CommandText = "DELETE FROM movimientos WHERE id = $id;";
        comando.Parameters.AddWithValue("$id", id);
        comando.ExecuteNonQuery();
    }
}
