using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media;
using ControlGastos.Data;
using ControlGastos.Models;
using ControlGastos.Services;

namespace ControlGastos;

/// <summary>
/// Ventana principal: solo maneja eventos de la interfaz y delega
/// toda la lógica en MovimientoServicio.
/// </summary>
public partial class MainWindow : Window
{
    private readonly MovimientoServicio _servicio;
    private Movimiento? _seleccionado;

    public MainWindow()
    {
        InitializeComponent();

        // La base de datos se crea automáticamente junto al ejecutable.
        string ruta = Path.Combine(AppContext.BaseDirectory, "gastos.db");
        _servicio = new MovimientoServicio(new MovimientoDAO(ruta));

        TipoComboBox.ItemsSource = MovimientoServicio.Tipos;
        TipoComboBox.SelectedIndex = 0;

        CargarMovimientos();
    }

    // ---------- Eventos de los botones ----------

    private void GuardarButton_Click(object? sender, RoutedEventArgs e)
    {
        try
        {
            string? error = _servicio.Agregar(
                DescripcionTextBox.Text, MontoTextBox.Text, TipoComboBox.SelectedItem as string);

            if (error != null)
            {
                MostrarMensaje(error, true);
                return;
            }

            LimpiarFormulario();
            CargarMovimientos();
            MostrarMensaje("Movimiento guardado correctamente.", false);
        }
        catch (Exception ex)
        {
            MostrarMensaje("Error inesperado: " + ex.Message, true);
        }
    }

    private void ActualizarButton_Click(object? sender, RoutedEventArgs e)
    {
        if (_seleccionado == null)
        {
            MostrarMensaje("Selecciona un movimiento de la tabla para actualizarlo.", true);
            return;
        }

        try
        {
            string? error = _servicio.Actualizar(
                _seleccionado.Id, DescripcionTextBox.Text, MontoTextBox.Text,
                TipoComboBox.SelectedItem as string, _seleccionado.Fecha);

            if (error != null)
            {
                MostrarMensaje(error, true);
                return;
            }

            LimpiarFormulario();
            CargarMovimientos();
            MostrarMensaje("Movimiento actualizado correctamente.", false);
        }
        catch (Exception ex)
        {
            MostrarMensaje("Error inesperado: " + ex.Message, true);
        }
    }

    private void EliminarButton_Click(object? sender, RoutedEventArgs e)
    {
        if (_seleccionado == null)
        {
            MostrarMensaje("Selecciona un movimiento de la tabla para eliminarlo.", true);
            return;
        }

        try
        {
            _servicio.Eliminar(_seleccionado.Id);
            LimpiarFormulario();
            CargarMovimientos();
            MostrarMensaje("Movimiento eliminado correctamente.", false);
        }
        catch (Exception ex)
        {
            MostrarMensaje("Error inesperado: " + ex.Message, true);
        }
    }

    private void LimpiarButton_Click(object? sender, RoutedEventArgs e)
    {
        LimpiarFormulario();
        MostrarMensaje("Formulario limpio.", false);
    }

    // Al elegir una fila, sus datos pasan al formulario para poder editarlos.
    private void MovimientosDataGrid_SelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        _seleccionado = MovimientosDataGrid.SelectedItem as Movimiento;

        if (_seleccionado != null)
        {
            DescripcionTextBox.Text = _seleccionado.Descripcion;
            MontoTextBox.Text = _seleccionado.Monto.ToString();
            TipoComboBox.SelectedItem = _seleccionado.Tipo;
        }
    }

    // ---------- Métodos auxiliares ----------

    private void CargarMovimientos()
    {
        var lista = _servicio.Listar();
        MovimientosDataGrid.ItemsSource = lista;
        BalanceTextBlock.Text = $"Balance (ingresos - gastos): {_servicio.CalcularBalance(lista):N2}";
    }

    private void LimpiarFormulario()
    {
        MovimientosDataGrid.SelectedItem = null;
        _seleccionado = null;
        DescripcionTextBox.Text = "";
        MontoTextBox.Text = "";
        TipoComboBox.SelectedIndex = 0;
    }

    private void MostrarMensaje(string texto, bool esError)
    {
        MensajeTextBlock.Text = texto;
        MensajeTextBlock.Foreground = esError ? Brushes.Firebrick : Brushes.SeaGreen;
    }
}
