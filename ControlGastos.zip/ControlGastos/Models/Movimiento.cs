namespace ControlGastos.Models;

/// <summary>
/// Representa un ingreso o un gasto. Los campos son privados y las propiedades
/// validan los datos (encapsulamiento): un Movimiento nunca queda en estado inválido.
/// </summary>
public class Movimiento
{
    private string _descripcion = "";
    private decimal _monto;
    private string _tipo = "Gasto";

    public int Id { get; private set; }

    public string Descripcion
    {
        get => _descripcion;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("La descripción es obligatoria.");
            if (value.Trim().Length > 100)
                throw new ArgumentException("La descripción no puede superar los 100 caracteres.");
            _descripcion = value.Trim();
        }
    }

    public decimal Monto
    {
        get => _monto;
        set
        {
            if (value <= 0)
                throw new ArgumentException("El monto debe ser mayor que cero.");
            _monto = value;
        }
    }

    public string Tipo
    {
        get => _tipo;
        set
        {
            if (value != "Ingreso" && value != "Gasto")
                throw new ArgumentException("Debes seleccionar un tipo: Ingreso o Gasto.");
            _tipo = value;
        }
    }

    public string Fecha { get; private set; }

    // Constructor: usa las propiedades para que se apliquen las validaciones.
    public Movimiento(int id, string descripcion, decimal monto, string tipo, string fecha)
    {
        Id = id;
        Descripcion = descripcion;
        Monto = monto;
        Tipo = tipo;
        Fecha = fecha;
    }
}
